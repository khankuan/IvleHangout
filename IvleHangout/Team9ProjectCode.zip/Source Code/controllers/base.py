import tornado.web


class BaseHandler(tornado.web.RequestHandler):

    def render_string(self, template_name, **kwargs):
        # Let the templates access the users module to generate login URLs
        return tornado.web.RequestHandler.render_string(
            self, template_name, **kwargs)